#!/bin/bash

#Tested on Ubuntu 16.04.




echo -e "\n\nDownloading darknet\n\n"
wget https://www.dropbox.com/s/9nxzvyyi53bi4p4/darknet?dl=0
mv darknet?dl=0 darknet
chmod 755 darknet


#needed darknet. Moved to pwd.
